# Luxora Digital Marketing

A luxury brand growth consultancy website built with React + Vite.

## Local Development

```bash
npm install
npm run dev
```

## Deploy to Vercel

### Option 1 — Vercel CLI
```bash
npm install -g vercel
vercel
```

### Option 2 — GitHub + Vercel Dashboard
1. Push this repo to GitHub
2. Go to vercel.com → Add New Project
3. Import your GitHub repo
4. Vercel auto-detects Vite — click Deploy

## Build
```bash
npm run build
```
Output goes to `/dist` folder.
