import { useState, useEffect, useRef } from "react";

const GOLD = "#b8922a";
const GOLD_LIGHT = "#d4a94a";
const CHARCOAL = "#1a1814";
const WHITE = "#ffffff";
const OFF_WHITE = "#faf8f5";
const BORDER = "#e8e2d9";
const MUTED = "#8a8278";

function useCounter(target, duration = 1800, start = false) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime = null;
    const step = (ts) => {
      if (!startTime) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setVal(Math.floor(ease * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [start, target, duration]);
  return val;
}

function useInView(threshold = 0.15) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return [ref, inView];
}

function FadeUp({ children, delay = 0, style = {} }) {
  const [ref, inView] = useInView();
  return (
    <div ref={ref} style={{
      opacity: inView ? 1 : 0,
      transform: inView ? "translateY(0)" : "translateY(32px)",
      transition: `opacity 0.85s ease ${delay}s, transform 0.85s ease ${delay}s`,
      ...style
    }}>
      {children}
    </div>
  );
}

function StatCard({ num, suffix = "", label, start }) {
  const val = useCounter(num, 1600, start);
  return (
    <div style={{ minWidth: 140 }}>
      <div style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: "2.6rem", fontWeight: 300, color: GOLD, lineHeight: 1 }}>
        {val}{suffix}
      </div>
      <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.18em", textTransform: "uppercase", color: MUTED, marginTop: 6 }}>
        {label}
      </div>
    </div>
  );
}

const Ornament = () => (
  <svg width="60" height="12" viewBox="0 0 60 12" fill="none">
    <line x1="0" y1="6" x2="22" y2="6" stroke={GOLD} strokeWidth="0.8" opacity="0.6" />
    <polygon points="30,1 33,6 30,11 27,6" fill={GOLD} opacity="0.8" />
    <line x1="38" y1="6" x2="60" y2="6" stroke={GOLD} strokeWidth="0.8" opacity="0.6" />
  </svg>
);

const Label = ({ children, light = false }) => (
  <div style={{
    fontFamily: "sans-serif", fontSize: "0.6rem", letterSpacing: "0.32em",
    textTransform: "uppercase", color: light ? GOLD_LIGHT : GOLD, marginBottom: 12
  }}>
    {children}
  </div>
);

const Divider = ({ style = {} }) => (
  <div style={{ height: 1, background: `linear-gradient(to right, transparent, ${BORDER}, transparent)`, ...style }} />
);

const globalStyles = `
  .gold-hover:hover { color: ${GOLD} !important; }
  .card-hover { transition: all 0.35s ease; cursor: default; }
  .card-hover:hover { background: #faf8f5 !important; box-shadow: 0 8px 40px rgba(184,146,42,0.1) !important; transform: translateY(-2px); }
  .btn-gold { transition: all 0.3s ease; display: inline-block; }
  .btn-gold:hover { background: ${CHARCOAL} !important; transform: translateY(-1px); }
  .btn-outline { transition: all 0.3s ease; }
  .btn-outline:hover { background: ${GOLD} !important; color: white !important; }
  input:focus, select:focus, textarea:focus {
    outline: none;
    border-color: ${GOLD} !important;
    box-shadow: 0 0 0 3px rgba(184,146,42,0.1) !important;
  }
  @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
  @keyframes scrollLine {
    0%, 100% { opacity: 0.3; transform: scaleY(0.5) translateY(-20px); }
    50% { opacity: 1; transform: scaleY(1) translateY(0); }
  }
`;

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [hoveredService, setHoveredService] = useState(null);
  const [statsRef, statsInView] = useInView(0.3);
  const [formData, setFormData] = useState({ name: "", email: "", company: "", industry: "", budget: "", objective: "" });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const services = [
    { num: "01", title: "Luxury Brand Positioning", tag: "Authority Architecture", body: "We establish and fortify your brand's position as the definitive authority in your category. From competitive differentiation strategy to prestige narrative development, we ensure your brand commands the premium it deserves across every digital environment." },
    { num: "02", title: "Customer Acquisition Systems", tag: "Precision Growth", body: "Multi-channel acquisition ecosystems attract qualified, high-intent prospects who match your ideal client profile precisely. We identify, target, and engage affluent audiences with the precision required to protect your brand's exclusivity while driving consistent revenue growth." },
    { num: "03", title: "Conversion Architecture", tag: "Revenue Engineering", body: "We design the complete conversion journey from first interaction to closed transaction, ensuring every touchpoint reflects your brand's prestige and removes friction from the path to purchase. Our systems consistently outperform industry benchmarks by 3 to 5 times." },
    { num: "04", title: "Luxury Website Experiences", tag: "Digital Flagship Design", body: "Your digital presence must embody the same caliber as your physical brand. We design and build immersive, conversion-optimized website experiences that communicate luxury at every scroll while driving measurable business outcomes." },
    { num: "05", title: "Revenue Growth Infrastructure", tag: "Scalable Systems", body: "The underlying technology and data infrastructure that powers sustainable growth. CRM architecture, analytics frameworks, attribution modeling, and revenue reporting systems provide complete visibility into your growth performance." },
    { num: "06", title: "Marketing Automation Ecosystems", tag: "Intelligent Nurture", body: "Sophisticated automation architectures nurture prospects, reactivate dormant clients, and drive repeat purchase at the level of personalization luxury consumers demand and expect from brands at your caliber." },
    { num: "07", title: "Market Expansion Strategy", tag: "Geographic Growth", body: "Strategic roadmaps and execution frameworks for expanding into new markets, demographics, or geographies while protecting the brand equity you have built. We identify high-value expansion opportunities and build the systems to capture them efficiently." },
  ];

  const cases = [
    { industry: "Luxury Real Estate · New York", title: "From Market Noise to Category Authority", body: "A Manhattan luxury developer rebuilt their complete digital ecosystem, from brand positioning and website experience to a targeted acquisition system reaching UHNW buyers across digital and programmatic channels.", metrics: [{ val: "412%", label: "Qualified Lead Growth" }, { val: "$280M", label: "Pipeline Generated" }, { val: "47%", label: "Faster Sales Cycle" }] },
    { industry: "Fine Dining · Los Angeles", title: "Transforming Reservations Into Revenue", body: "A Michelin-recognized fine dining group across three locations received a full brand overhaul, editorial website redesign, and a private events acquisition funnel targeting corporate clients and high-net-worth individuals.", metrics: [{ val: "290%", label: "Private Event Growth" }, { val: "$4.2M", label: "Additional Revenue" }, { val: "3.8×", label: "Return on Investment" }] },
    { industry: "Private Medical Aesthetics · Miami", title: "Building a Premium Patient Acquisition Engine", body: "A luxury aesthetic clinic group with expansion goals received a discreet, high-converting patient acquisition ecosystem leveraging intent-based digital targeting and a comprehensive CRM automation system.", metrics: [{ val: "360%", label: "Patient Acquisition Growth" }, { val: "78%", label: "Reduction in CPL" }, { val: "$6.8M", label: "Revenue in 18 Months" }] },
    { industry: "Prestige Skincare · National DTC", title: "Scaling a $40M Brand to Category Leader", body: "A prestige skincare brand sought to scale to $100M while defending luxury positioning. We delivered market dominance architecture including audience expansion, premium content ecosystem, and retention systems.", metrics: [{ val: "167%", label: "Revenue Growth" }, { val: "$107M", label: "Revenue Achieved" }, { val: "52%", label: "Repeat Purchase Increase" }] },
  ];

  const tiers = [
    { name: "Growth Foundation", tag: "For Emerging Luxury Brands", range: "$1M to $10M Revenue", featured: false, items: ["Brand Positioning Strategy", "Digital Presence Audit and Roadmap", "Primary Acquisition Channel Build", "Conversion Funnel Architecture", "CRM Setup and Automation Foundation", "Monthly Strategy and Performance Reviews", "Dedicated Growth Strategist"] },
    { name: "Growth Accelerator", tag: "For Scaling Luxury Brands", range: "$10M to $50M Revenue", featured: true, items: ["Full Growth Architecture Design", "Multi-Channel Acquisition System", "Luxury Website Experience Build", "Complete Conversion Infrastructure", "Advanced Marketing Automation", "Revenue Analytics and Attribution", "Bi-Weekly Executive Strategy Sessions", "Dedicated Senior Strategy Team", "Priority Access and Response"] },
    { name: "Market Dominance", tag: "For Category Leaders", range: "$50M and Above", featured: false, items: ["C-Suite Growth Strategy Partnership", "Complete Digital Ecosystem Build", "Market Expansion Strategy and Execution", "Competitive Intelligence Program", "Custom Technology Infrastructure", "Enterprise CRM and Revenue Operations", "Dedicated Executive Consultant Access", "Weekly Strategy Leadership Sessions", "Quarterly Board Reporting"] },
  ];

  const industries = ["Luxury Fashion", "Fine Hospitality", "Luxury Real Estate", "Fine Dining", "Private Healthcare", "Prestige Beauty", "Luxury Automotive", "High-End Lifestyle"];

  return (
    <div style={{ fontFamily: "'Georgia', serif", background: WHITE, color: CHARCOAL, overflowX: "hidden" }}>
      <style>{globalStyles}</style>

      {/* ── NAV ── */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 200,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "1.4rem 3rem",
        background: scrolled ? "rgba(255,255,255,0.97)" : "transparent",
        borderBottom: scrolled ? `1px solid ${BORDER}` : "1px solid transparent",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        boxShadow: scrolled ? "0 2px 24px rgba(26,24,20,0.06)" : "none",
        transition: "all 0.5s ease",
      }}>
        <div onClick={() => navTo("home")} style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: "1.45rem", fontWeight: 300, letterSpacing: "0.22em", cursor: "pointer", color: CHARCOAL }}>
          LUXO<span style={{ color: GOLD }}>R</span>A
        </div>
        <div style={{ display: "flex", gap: "2.4rem", alignItems: "center" }}>
          {[{ id: "services", label: "Services" }, { id: "cases", label: "Case Studies" }, { id: "engagement", label: "Engagement" }, { id: "about", label: "About" }].map(s => (
            <span key={s.id} className="gold-hover" onClick={() => navTo(s.id)} style={{ fontFamily: "sans-serif", fontSize: "0.6rem", letterSpacing: "0.2em", textTransform: "uppercase", color: MUTED, cursor: "pointer", transition: "color 0.3s" }}>
              {s.label}
            </span>
          ))}
          <span onClick={() => navTo("contact")} className="btn-gold" style={{ fontFamily: "sans-serif", fontSize: "0.6rem", letterSpacing: "0.2em", textTransform: "uppercase", color: WHITE, background: GOLD, padding: "0.65rem 1.6rem", cursor: "pointer" }}>
            Private Consultation
          </span>
        </div>
      </nav>

      {/* ── HERO ── */}
      <div id="home" style={{
        minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "flex-end",
        padding: "0 3rem 6rem",
        background: `radial-gradient(ellipse 70% 60% at 65% 30%, rgba(184,146,42,0.08) 0%, transparent 65%), linear-gradient(180deg, #faf8f5 0%, #ffffff 100%)`,
        position: "relative", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", top: 0, right: "14%", width: 1, height: "100%", background: `linear-gradient(to bottom, transparent, ${BORDER} 40%, transparent)` }} />
        <div style={{ position: "absolute", right: "-2%", top: "8%", fontFamily: "'Cormorant Garamond', serif", fontSize: "32vw", fontWeight: 300, color: "rgba(184,146,42,0.04)", lineHeight: 1, pointerEvents: "none", userSelect: "none" }}>L</div>

        <FadeUp>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 28 }}>
            <div style={{ width: 40, height: 1, background: GOLD }} />
            <Label>Luxury Brand Growth Partner · USA</Label>
          </div>
          <h1 style={{ fontFamily: "'Cormorant Garamond', Georgia, serif", fontSize: "clamp(3rem, 7.5vw, 7rem)", fontWeight: 300, color: CHARCOAL, lineHeight: 1.1, maxWidth: 860, marginBottom: 24 }}>
            Where <em style={{ color: GOLD, fontStyle: "italic" }}>Luxury Brands</em><br />Engineer Predictable<br />Revenue Growth
          </h1>
          <p style={{ fontFamily: "sans-serif", fontSize: "0.78rem", letterSpacing: "0.09em", color: MUTED, maxWidth: 480, lineHeight: 1.95, marginBottom: 36 }}>
            Luxora designs full-spectrum digital growth ecosystems for the world's most discerning brands, delivering measurable results while honoring the prestige you have built.
          </p>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <span onClick={() => navTo("contact")} className="btn-gold" style={{ fontFamily: "sans-serif", fontSize: "0.62rem", letterSpacing: "0.24em", textTransform: "uppercase", color: WHITE, background: GOLD, padding: "1rem 2.6rem", cursor: "pointer" }}>
              Schedule a Private Consultation
            </span>
            <span onClick={() => navTo("cases")} className="btn-outline" style={{ fontFamily: "sans-serif", fontSize: "0.62rem", letterSpacing: "0.24em", textTransform: "uppercase", color: GOLD, background: "transparent", padding: "1rem 2.6rem", border: `1px solid ${GOLD}`, cursor: "pointer" }}>
              View Case Studies
            </span>
          </div>
        </FadeUp>

        <div ref={statsRef} style={{ display: "flex", gap: "3.5rem", marginTop: "4.5rem", paddingTop: "3rem", borderTop: `1px solid ${BORDER}`, flexWrap: "wrap" }}>
          <StatCard num={2} suffix="B+" label="Revenue Generated for Clients" start={statsInView} />
          <StatCard num={340} suffix="%" label="Average Client Revenue Growth" start={statsInView} />
          <StatCard num={120} suffix="+" label="Luxury Brand Partnerships" start={statsInView} />
          <StatCard num={98} suffix="%" label="Client Retention Rate" start={statsInView} />
        </div>
      </div>

      {/* ── MARQUEE ── */}
      <div style={{ background: CHARCOAL, padding: "1rem 0", overflow: "hidden" }}>
        <div style={{ display: "flex", animation: "marquee 28s linear infinite", whiteSpace: "nowrap" }}>
          {[...industries, ...industries].map((ind, i) => (
            <span key={i} style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.3em", textTransform: "uppercase", color: "rgba(255,255,255,0.35)", padding: "0 2.5rem", flexShrink: 0 }}>
              {ind} <span style={{ color: GOLD, marginLeft: "2.5rem" }}>◆</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── VALUE PROP ── */}
      <div style={{ padding: "8rem 3rem", background: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6rem", alignItems: "start" }}>
          <FadeUp>
            <Label>Our Distinction</Label>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 3.5vw, 3.5rem)", fontWeight: 300, color: CHARCOAL, lineHeight: 1.15, marginBottom: 32 }}>
              Beyond a Marketing Agency.<br /><em style={{ color: GOLD, fontStyle: "italic" }}>A Growth Architecture Firm.</em>
            </h2>
            <div style={{ width: 60, height: 2, background: `linear-gradient(to right, ${GOLD}, transparent)`, marginBottom: 32 }} />
            <p style={{ color: MUTED, lineHeight: 1.9, marginBottom: 16, fontSize: "1rem" }}>Luxora was built on one conviction: luxury brands require a fundamentally different growth philosophy. Prestige must be protected through every channel. Acquisition must strengthen authority.</p>
            <p style={{ color: MUTED, lineHeight: 1.9, fontSize: "1rem" }}>We architect comprehensive digital growth ecosystems that operate across every touchpoint of your customer's journey, from first awareness to lifetime loyalty.</p>
          </FadeUp>
          <FadeUp delay={0.2}>
            {[
              { n: "01", title: "Systems Over Tactics", body: "We build interconnected growth infrastructure that scales with your brand, generating compounding returns across every channel over time." },
              { n: "02", title: "Luxury Brand Intelligence", body: "Deep understanding of the psychology and decision cycles of ultra-high-net-worth consumers guides every strategy we design." },
              { n: "03", title: "Revenue-First Design", body: "Every strategy, platform, and creative decision is engineered to generate qualified leads and measurable revenue at the highest level." },
              { n: "04", title: "Prestige Preservation", body: "True growth strengthens brand equity. We protect what you have built while expanding your reach into the markets you deserve." },
            ].map((p, i) => (
              <div key={i} style={{ display: "flex", gap: 20, padding: "1.8rem 0", borderBottom: `1px solid ${BORDER}`, borderTop: i === 0 ? `1px solid ${BORDER}` : "none" }}>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "0.9rem", color: GOLD, opacity: 0.6, flexShrink: 0, marginTop: 2 }}>{p.n}</div>
                <div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.65rem", letterSpacing: "0.16em", textTransform: "uppercase", color: CHARCOAL, marginBottom: 6 }}>{p.title}</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.67rem", color: MUTED, lineHeight: 1.8 }}>{p.body}</div>
                </div>
              </div>
            ))}
          </FadeUp>
        </div>
      </div>

      {/* ── FRAMEWORK ── */}
      <div style={{ padding: "8rem 3rem", background: OFF_WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <FadeUp>
            <div style={{ textAlign: "center", marginBottom: "4rem" }}>
              <Label>The Luxora Method</Label>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 4vw, 4rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0" }}>
                The <em style={{ color: GOLD }}>Luxora Growth</em> Framework
              </h2>
              <div style={{ display: "flex", justifyContent: "center", margin: "16px 0" }}><Ornament /></div>
              <p style={{ fontFamily: "sans-serif", fontSize: "0.72rem", color: MUTED, maxWidth: 520, margin: "0 auto", lineHeight: 1.9 }}>
                A proprietary five-phase system designed exclusively for luxury brands that demand precision, discretion, and compounding results.
              </p>
            </div>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 1, background: BORDER }}>
            {[
              { n: "01", title: "Brand Intelligence Audit", body: "Deep analysis of your market position, competitive landscape, and untapped revenue opportunities." },
              { n: "02", title: "Growth Architecture Design", body: "Engineering a bespoke digital ecosystem built around your brand's unique positioning and ambitions." },
              { n: "03", title: "Acquisition System Deployment", body: "Precision-targeted campaigns that attract ideal clients while preserving your brand's prestige." },
              { n: "04", title: "Conversion Infrastructure", body: "High-converting digital experiences that reflect your brand's caliber at every touchpoint." },
              { n: "05", title: "Optimize and Scale", body: "Continuous data analysis and refinement to compound your growth trajectory every quarter." },
            ].map((step, i) => (
              <FadeUp key={i} delay={i * 0.08}>
                <div className="card-hover" style={{ background: WHITE, padding: "2.5rem 2rem", position: "relative", overflow: "hidden", height: "100%" }}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2.8rem", fontWeight: 300, color: BORDER, lineHeight: 1, marginBottom: 20 }}>{step.n}</div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.2rem", color: CHARCOAL, marginBottom: 12 }}>{step.title}</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.63rem", color: MUTED, lineHeight: 1.85 }}>{step.body}</div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>

      {/* ── INDUSTRIES ── */}
      <div style={{ padding: "8rem 3rem", background: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <FadeUp>
            <Label>Sectors We Serve</Label>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 3.5vw, 3.5rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 48px" }}>
              Built for the World's<br />Most Prestigious Brands
            </h2>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1, background: BORDER }}>
            {[
              { title: "Luxury Fashion", body: "Growth strategies honoring heritage and craftsmanship while expanding digital revenue and market reach." },
              { title: "Fine Hospitality", body: "Reservation-driving ecosystems for five-star hotels, members clubs, and ultra-luxury travel experiences." },
              { title: "Luxury Real Estate", body: "Qualified buyer acquisition for premier residential developments and private estates across the USA." },
              { title: "Fine Dining", body: "Reservation optimization and private event growth for Michelin-caliber dining establishments." },
              { title: "Private Healthcare", body: "Discreet, high-converting patient acquisition for concierge medicine and luxury wellness retreats." },
              { title: "Prestige Beauty", body: "Building dominant digital authority for luxury skincare and cosmetics brands in global markets." },
              { title: "Luxury Automotive", body: "Lead generation and buyer journey optimization for exotic dealers and premium automotive brands." },
              { title: "Lifestyle Brands", body: "Full growth systems for private aviation, luxury yachting, and bespoke lifestyle service providers." },
            ].map((ind, i) => (
              <FadeUp key={i} delay={(i % 4) * 0.07}>
                <div className="card-hover" style={{ background: WHITE, padding: "2.5rem 2rem", position: "relative", overflow: "hidden" }}>
                  <div style={{ fontSize: "1.2rem", color: GOLD, marginBottom: 16, opacity: 0.7 }}>◈</div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.2rem", color: CHARCOAL, marginBottom: 10, fontWeight: 400 }}>{ind.title}</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.63rem", color: MUTED, lineHeight: 1.85 }}>{ind.body}</div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>

      {/* ── SERVICES ── */}
      <div id="services" style={{ padding: "8rem 3rem", background: OFF_WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <FadeUp>
            <div style={{ textAlign: "center", marginBottom: "4rem" }}>
              <Label>Our Capabilities</Label>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 4vw, 4rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 12px" }}>
                Outcome-Based Growth Systems
              </h2>
              <p style={{ fontFamily: "sans-serif", fontSize: "0.72rem", color: MUTED, maxWidth: 520, margin: "0 auto", lineHeight: 1.9 }}>
                We design comprehensive growth ecosystems, each engineered around a measurable revenue objective built to scale with your brand's ambitions.
              </p>
            </div>
          </FadeUp>
          <div>
            {services.map((svc, i) => (
              <FadeUp key={i} delay={0.05}>
                <div
                  onMouseEnter={() => setHoveredService(i)}
                  onMouseLeave={() => setHoveredService(null)}
                  style={{
                    display: "grid", gridTemplateColumns: "70px 1fr 1.1fr", gap: "2.5rem",
                    padding: "3rem 2rem", borderBottom: `1px solid ${BORDER}`,
                    borderTop: i === 0 ? `1px solid ${BORDER}` : "none",
                    background: hoveredService === i ? "rgba(184,146,42,0.03)" : "transparent",
                    transition: "background 0.3s", cursor: "default",
                  }}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1rem", color: GOLD, opacity: 0.55, paddingTop: 4 }}>{svc.num}</div>
                  <div>
                    <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.65rem", fontWeight: 300, color: CHARCOAL, marginBottom: 6 }}>{svc.title}</h3>
                    <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD }}>{svc.tag}</div>
                  </div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.67rem", color: MUTED, lineHeight: 1.9 }}>{svc.body}</div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>

      {/* ── CASE STUDIES ── */}
      <div id="cases" style={{ padding: "8rem 3rem", background: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <FadeUp>
            <Label>Proven Results</Label>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 4vw, 4rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 48px", maxWidth: 600 }}>
              Growth That Speaks<br />for <em style={{ color: GOLD }}>Itself</em>
            </h2>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, background: BORDER }}>
            {cases.map((c, i) => (
              <FadeUp key={i} delay={(i % 2) * 0.1}>
                <div className="card-hover" style={{ background: WHITE, padding: "3.5rem", position: "relative" }}>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD, marginBottom: 20 }}>{c.industry}</div>
                  <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.7rem", fontWeight: 300, color: CHARCOAL, marginBottom: 16, lineHeight: 1.2 }}>{c.title}</h3>
                  <p style={{ fontFamily: "sans-serif", fontSize: "0.66rem", color: MUTED, lineHeight: 1.9, marginBottom: 28 }}>{c.body}</p>
                  <Divider style={{ marginBottom: 24 }} />
                  <div style={{ display: "flex", gap: "2rem" }}>
                    {c.metrics.map((m, j) => (
                      <div key={j}>
                        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2rem", fontWeight: 300, color: GOLD, lineHeight: 1 }}>{m.val}</div>
                        <div style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.14em", textTransform: "uppercase", color: MUTED, marginTop: 4 }}>{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>

      {/* ── ENGAGEMENT ── */}
      <div id="engagement" style={{ padding: "8rem 3rem", background: OFF_WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <FadeUp>
            <div style={{ textAlign: "center", marginBottom: "4rem" }}>
              <Label>Engagement Models</Label>
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 4vw, 4rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 12px" }}>Designed for Ambition</h2>
              <p style={{ fontFamily: "sans-serif", fontSize: "0.72rem", color: MUTED, maxWidth: 500, margin: "0 auto", lineHeight: 1.9 }}>Three consulting tiers, each designed to meet luxury brands at a precise stage of their growth journey.</p>
            </div>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1, background: BORDER }}>
            {tiers.map((tier, i) => (
              <FadeUp key={i} delay={i * 0.1}>
                <div style={{ background: tier.featured ? CHARCOAL : WHITE, padding: "3.5rem 2.8rem", display: "flex", flexDirection: "column", position: "relative", borderTop: tier.featured ? `2px solid ${GOLD}` : "none", height: "100%" }}>
                  {tier.featured && (
                    <div style={{ position: "absolute", top: -1, right: 24, fontFamily: "sans-serif", fontSize: "0.52rem", letterSpacing: "0.2em", textTransform: "uppercase", background: GOLD, color: WHITE, padding: "0.28rem 0.9rem" }}>Most Engaged</div>
                  )}
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.9rem", fontWeight: 300, color: tier.featured ? WHITE : CHARCOAL, marginBottom: 4 }}>{tier.name}</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.18em", textTransform: "uppercase", color: tier.featured ? GOLD_LIGHT : GOLD, marginBottom: 8 }}>{tier.tag}</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.62rem", color: tier.featured ? "rgba(255,255,255,0.5)" : MUTED, marginBottom: 20, paddingBottom: 20, borderBottom: `1px solid ${tier.featured ? "rgba(255,255,255,0.1)" : BORDER}` }}>{tier.range}</div>
                  <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 12, flex: 1, marginBottom: 32 }}>
                    {tier.items.map((item, j) => (
                      <li key={j} style={{ display: "flex", gap: 12, alignItems: "flex-start", fontFamily: "sans-serif", fontSize: "0.66rem", color: tier.featured ? "rgba(255,255,255,0.6)" : MUTED, lineHeight: 1.5 }}>
                        <span style={{ color: GOLD_LIGHT, fontSize: "0.4rem", marginTop: 5, flexShrink: 0 }}>◆</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                  <span onClick={() => navTo("contact")} className={tier.featured ? "btn-gold" : "btn-outline"} style={{ display: "block", textAlign: "center", fontFamily: "sans-serif", fontSize: "0.6rem", letterSpacing: "0.22em", textTransform: "uppercase", color: tier.featured ? WHITE : GOLD, background: tier.featured ? GOLD : "transparent", padding: "1rem", border: tier.featured ? "none" : `1px solid ${GOLD}`, cursor: "pointer" }}>
                    Request Consultation
                  </span>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>

      {/* ── ABOUT ── */}
      <div id="about" style={{ padding: "8rem 3rem", background: WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6rem" }}>
          <FadeUp>
            <Label>Our Philosophy</Label>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 3.5vw, 3.5rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 24px", lineHeight: 1.15 }}>
              Growth That<br />Honors <em style={{ color: GOLD }}>Prestige</em>
            </h2>
            <p style={{ color: MUTED, lineHeight: 1.9, marginBottom: 16, fontSize: "1rem" }}>Luxora was founded on a single conviction: luxury brands have been underserved by the marketing industry. Traditional agencies apply mass-market tactics to premium brands, commoditizing what deserves to be protected.</p>
            <p style={{ color: MUTED, lineHeight: 1.9, fontSize: "1rem", marginBottom: 40 }}>We operate at the intersection of luxury brand strategy, digital infrastructure, and data-driven growth systems.</p>
            {[
              { title: "Luxury Demands a Different Approach", body: "Luxury consumers respond to authority, aspiration, and trust. Our methodologies are built around the psychology of affluent and ultra-high-net-worth individuals." },
              { title: "We Think in Systems, Always", body: "Every engagement begins with infrastructure. We build growth systems that operate continuously, generating compounding returns that become more efficient over time." },
              { title: "Discretion Is a Professional Standard", body: "We operate with complete discretion, protecting your competitive strategy and the privacy of your client relationships at all times." },
              { title: "Results Are the Only Metric", body: "We measure our success by one standard: your revenue growth. Every engagement is structured around clear performance objectives we fully own." },
            ].map((p, i) => (
              <div key={i} style={{ padding: "1.8rem 0", borderBottom: `1px solid ${BORDER}`, borderTop: i === 0 ? `1px solid ${BORDER}` : "none" }}>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.2rem", color: CHARCOAL, marginBottom: 8 }}>{p.title}</div>
                <div style={{ fontFamily: "sans-serif", fontSize: "0.66rem", color: MUTED, lineHeight: 1.85 }}>{p.body}</div>
              </div>
            ))}
          </FadeUp>
          <FadeUp delay={0.2}>
            <div style={{ paddingTop: "3rem" }}>
              <div style={{ padding: "2.5rem", background: OFF_WHITE, borderLeft: `3px solid ${GOLD}`, marginBottom: 32 }}>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.7rem", fontStyle: "italic", color: CHARCOAL, lineHeight: 1.45 }}>
                  "The most sophisticated brands deserve the most sophisticated growth partner, one that understands that{" "}
                  <span style={{ color: GOLD }}>growth and prestige are entirely aligned.</span>"
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "1.8rem 2rem", border: `1px solid ${BORDER}`, background: WHITE, marginBottom: 32 }}>
                <div style={{ width: 52, height: 52, borderRadius: "50%", background: `linear-gradient(135deg, #f0e4c4, ${BORDER})`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Cormorant Garamond', serif", fontSize: "1.1rem", color: GOLD, flexShrink: 0 }}>L</div>
                <div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.05rem", color: CHARCOAL }}>Leadership Team, Luxora Digital</div>
                  <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.14em", textTransform: "uppercase", color: MUTED, marginTop: 3 }}>Luxury Brand Growth Consultants</div>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                {[
                  { title: "Luxury Exclusive", body: "We work exclusively with luxury and premium brands, ensuring our methodologies are purpose-built for your market." },
                  { title: "Senior Attention", body: "You work directly with senior strategists throughout every engagement. Your growth is owned at the highest level." },
                  { title: "Selective Partnership", body: "We maintain a limited client portfolio to ensure exceptional attention and results for every brand we partner with." },
                  { title: "USA Focused", body: "Deep expertise in the U.S. luxury market, its consumers, channels, and the nuances of each regional audience." },
                ].map((d, i) => (
                  <div key={i} className="card-hover" style={{ padding: "1.6rem", border: `1px solid ${BORDER}`, background: WHITE }}>
                    <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.15em", textTransform: "uppercase", color: GOLD, marginBottom: 8 }}>{d.title}</div>
                    <div style={{ fontFamily: "sans-serif", fontSize: "0.63rem", color: MUTED, lineHeight: 1.8 }}>{d.body}</div>
                  </div>
                ))}
              </div>
            </div>
          </FadeUp>
        </div>
      </div>

      {/* ── CTA BAND ── */}
      <div style={{ padding: "7rem 3rem", background: CHARCOAL, textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 600, height: 300, background: `radial-gradient(ellipse, rgba(184,146,42,0.15), transparent 70%)`, pointerEvents: "none" }} />
        <FadeUp>
          <Label light>Begin Your Growth Journey</Label>
          <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.5rem, 5vw, 5rem)", fontWeight: 300, color: WHITE, maxWidth: 720, margin: "16px auto 20px", lineHeight: 1.1 }}>
            Is Your Brand<br />Ready to <em style={{ color: GOLD_LIGHT }}>Lead?</em>
          </h2>
          <p style={{ fontFamily: "sans-serif", fontSize: "0.72rem", color: "rgba(255,255,255,0.45)", maxWidth: 440, margin: "0 auto 36px", lineHeight: 1.95 }}>
            A private strategy consultation begins with a 60-minute analysis of your brand's current position, growth potential, and highest-leverage opportunities.
          </p>
          <span onClick={() => navTo("contact")} className="btn-gold" style={{ fontFamily: "sans-serif", fontSize: "0.62rem", letterSpacing: "0.24em", textTransform: "uppercase", color: WHITE, background: GOLD, padding: "1.1rem 3rem", cursor: "pointer" }}>
            Schedule a Private Strategy Consultation
          </span>
        </FadeUp>
      </div>

      {/* ── CONTACT ── */}
      <div id="contact" style={{ padding: "8rem 3rem", background: OFF_WHITE, borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "6rem" }}>
          <FadeUp>
            <Label>Private Consultation</Label>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(2.2rem, 3.5vw, 3.5rem)", fontWeight: 300, color: CHARCOAL, margin: "12px 0 20px" }}>Begin the<br />Conversation</h2>
            <p style={{ fontFamily: "sans-serif", fontSize: "0.7rem", color: MUTED, lineHeight: 1.9, marginBottom: 36 }}>Complete the form to request your private strategy consultation. We review all inquiries personally and respond within one business day.</p>
            {[
              { label: "Headquarters", val: "New York, New York, USA" },
              { label: "Serving", val: "Luxury Brands, United States" },
              { label: "Engagement", val: "By Invitation and Application" },
              { label: "Response Time", val: "Within One Business Day" },
            ].map((item, i) => (
              <div key={i} style={{ padding: "1.3rem 0", borderBottom: `1px solid ${BORDER}`, borderTop: i === 0 ? `1px solid ${BORDER}` : "none" }}>
                <div style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.2em", textTransform: "uppercase", color: GOLD, marginBottom: 4 }}>{item.label}</div>
                <div style={{ fontFamily: "'EB Garamond', serif", fontSize: "1rem", color: CHARCOAL }}>{item.val}</div>
              </div>
            ))}
          </FadeUp>
          <FadeUp delay={0.2}>
            {!submitted ? (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                  {[
                    { label: "Full Name", key: "name", placeholder: "Alexandra Whitmore", type: "text" },
                    { label: "Email Address", key: "email", placeholder: "a.whitmore@brand.com", type: "email" },
                    { label: "Company Name", key: "company", placeholder: "Your Brand", type: "text" },
                  ].map(f => (
                    <div key={f.key} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                      <label style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.2em", textTransform: "uppercase", color: MUTED }}>{f.label}</label>
                      <input type={f.type} placeholder={f.placeholder} value={formData[f.key]} onChange={e => setFormData({ ...formData, [f.key]: e.target.value })}
                        style={{ background: WHITE, border: `1px solid ${BORDER}`, color: CHARCOAL, padding: "0.9rem 1rem", fontFamily: "'EB Garamond', serif", fontSize: "1rem", width: "100%" }} />
                    </div>
                  ))}
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    <label style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.2em", textTransform: "uppercase", color: MUTED }}>Industry</label>
                    <select value={formData.industry} onChange={e => setFormData({ ...formData, industry: e.target.value })}
                      style={{ background: WHITE, border: `1px solid ${BORDER}`, color: formData.industry ? CHARCOAL : MUTED, padding: "0.9rem 1rem", fontFamily: "'EB Garamond', serif", fontSize: "1rem", width: "100%", appearance: "none" }}>
                      <option value="">Select Industry</option>
                      {["Luxury Fashion", "Fine Hospitality", "Luxury Real Estate", "Fine Dining", "Private Healthcare", "Prestige Beauty", "Luxury Automotive", "Lifestyle Brand"].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 16 }}>
                  <label style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.2em", textTransform: "uppercase", color: MUTED }}>Monthly Marketing Investment</label>
                  <select value={formData.budget} onChange={e => setFormData({ ...formData, budget: e.target.value })}
                    style={{ background: WHITE, border: `1px solid ${BORDER}`, color: formData.budget ? CHARCOAL : MUTED, padding: "0.9rem 1rem", fontFamily: "'EB Garamond', serif", fontSize: "1rem", width: "100%", appearance: "none" }}>
                    <option value="">Select Investment Range</option>
                    {["$5,000 to $15,000 per month", "$15,000 to $30,000 per month", "$30,000 to $75,000 per month", "$75,000 to $150,000 per month", "$150,000 and above per month"].map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 24 }}>
                  <label style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.2em", textTransform: "uppercase", color: MUTED }}>Primary Growth Objective</label>
                  <textarea rows={4} placeholder="Describe your primary growth objective and what a transformative outcome would look like for your brand." value={formData.objective} onChange={e => setFormData({ ...formData, objective: e.target.value })}
                    style={{ background: WHITE, border: `1px solid ${BORDER}`, color: CHARCOAL, padding: "0.9rem 1rem", fontFamily: "'EB Garamond', serif", fontSize: "1rem", width: "100%", resize: "vertical" }} />
                </div>
                <span onClick={() => setSubmitted(true)} className="btn-gold" style={{ display: "block", textAlign: "center", fontFamily: "sans-serif", fontSize: "0.62rem", letterSpacing: "0.24em", textTransform: "uppercase", color: WHITE, background: GOLD, padding: "1.2rem", cursor: "pointer" }}>
                  Schedule a Private Strategy Consultation
                </span>
                <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.1em", color: MUTED, textAlign: "center", marginTop: 14 }}>
                  All inquiries are held in strict confidence. We review every submission personally.
                </div>
              </div>
            ) : (
              <div style={{ textAlign: "center", padding: "5rem 2rem", border: `1px solid ${BORDER}`, background: WHITE }}>
                <div style={{ color: GOLD, fontSize: "2rem", marginBottom: 16 }}>◆</div>
                <h3 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "2rem", color: GOLD, marginBottom: 12 }}>Consultation Requested</h3>
                <p style={{ fontFamily: "sans-serif", fontSize: "0.7rem", color: MUTED, letterSpacing: "0.08em", lineHeight: 1.9 }}>
                  Thank you for reaching out. A senior member of our team will review your inquiry and be in contact within one business day.
                </p>
              </div>
            )}
          </FadeUp>
        </div>
      </div>

      {/* ── FOOTER ── */}
      <footer style={{ background: CHARCOAL, padding: "5rem 3rem 3rem" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "4rem", marginBottom: "4rem", paddingBottom: "4rem", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
            <div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "1.4rem", fontWeight: 300, letterSpacing: "0.22em", color: WHITE, marginBottom: 16 }}>
                LUXO<span style={{ color: GOLD_LIGHT }}>R</span>A
              </div>
              <p style={{ fontFamily: "sans-serif", fontSize: "0.63rem", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, maxWidth: 260 }}>
                The premier luxury brand growth consultancy for high-end brands across the United States. We design full-spectrum digital growth ecosystems that generate predictable revenue while protecting prestige.
              </p>
            </div>
            {[
              { title: "Services", links: ["Brand Positioning", "Customer Acquisition", "Conversion Architecture", "Luxury Web Experiences", "Marketing Automation", "Market Expansion"] },
              { title: "Company", links: ["About Luxora", "Our Framework", "Case Studies", "Engagement Models", "Contact"] },
              { title: "Sectors", links: ["Luxury Fashion", "Fine Hospitality", "Luxury Real Estate", "Fine Dining", "Private Healthcare", "Prestige Beauty"] },
            ].map((col, i) => (
              <div key={i}>
                <div style={{ fontFamily: "sans-serif", fontSize: "0.56rem", letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD_LIGHT, marginBottom: 20 }}>{col.title}</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {col.links.map((link, j) => (
                    <span key={j} className="gold-hover" style={{ fontFamily: "sans-serif", fontSize: "0.63rem", color: "rgba(255,255,255,0.38)", cursor: "pointer", transition: "color 0.3s" }}>{link}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.12em", color: "rgba(255,255,255,0.28)" }}>© 2025 Luxora Digital Marketing. All Rights Reserved. United States.</div>
            <div style={{ display: "flex", gap: 28 }}>
              {["Privacy Policy", "Terms of Service", "Confidentiality"].map(l => (
                <span key={l} className="gold-hover" style={{ fontFamily: "sans-serif", fontSize: "0.58rem", letterSpacing: "0.12em", color: "rgba(255,255,255,0.28)", cursor: "pointer", transition: "color 0.3s" }}>{l}</span>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
